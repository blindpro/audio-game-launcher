import pygame
import os
import subprocess
import requests
import zipfile
from accessible_output2 import outputs

pygame.init()

screen_size = (800, 600)
screen = pygame.display.set_mode(screen_size)
pygame.display.set_caption("audiogame launcher")
ao = outputs.auto.Auto()

games = [
    {"name": "Executioner's Rage", "folder": "rage", "file": "rage.exe", "url": "https://dl.tweesecake.app/rage/rage1.5.0.zip"},
    {"name": "Crazy Party", "folder": "Crazy-Party-beta81", "file": "Crazy Party.exe", "url": "http://pragmapragma.free.fr/crazy-party/Crazy-Party-beta81.zip"},
    {"name": "The Killer", "folder": "tk", "file": "tk.exe", "url": "http://blindzone.eu/tk_2.00.8.zip"}
]

def find_and_run_game(game):
    main_dir = os.getcwd()
    game_dir = os.path.join(main_dir, game["folder"])
    game_file = os.path.join(game_dir, game["file"])

    # Check if the game file is directly in the game folder
    if os.path.exists(game_file):
        return run_game(game, game_dir, game_file)

    # Check in subdirectories
    for root, dirs, files in os.walk(game_dir):
        for file in files:
            if file.lower() == game["file"].lower():
                game_file = os.path.join(root, file)
                return run_game(game, root, game_file)
    return False

def run_game(game, game_dir, game_file):
    ao.output(f"Launching {game['name']}")
    os.chdir(game_dir)
    if game_file.endswith('.py'):
        subprocess.Popen(["python", game["file"]])
    else:
        subprocess.Popen([game["file"]])
    os.chdir(main_dir)
    return True

def download_game(game):
    ao.output(f"Downloading {game['name']}...")
    zip_path = f"{game['folder']}.zip"
    game_dir = game["folder"]
    try:
        response = requests.get(game["url"])
        with open(zip_path, "wb") as zip_file:
            zip_file.write(response.content)
        if not os.path.exists(game_dir):
            os.makedirs(game_dir)
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(game_dir)
        os.remove(zip_path)
        return True
    except Exception as e:
        print(f"Error downloading {game['name']}:", e)
        return False

running = True
selected_option = 0
menu_options = [game["name"] for game in games] + ["Exit"]

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                selected_option = (selected_option - 1) % len(menu_options)
                ao.output(menu_options[selected_option])
            elif event.key == pygame.K_DOWN:
                selected_option = (selected_option + 1) % len(menu_options)
                ao.output(menu_options[selected_option])
            elif event.key == pygame.K_RETURN:
                if selected_option < len(games):
                    game = games[selected_option]
                    if not find_and_run_game(game):
                        if download_game(game):
                            if not find_and_run_game(game):
                                ao.output(f"{game['name']} not found.")
                        else:
                            ao.output(f"{game['name']} not found.")
                else:
                    ao.output("Quitting the game")
                    running = False

    screen.fill((255, 255, 255))
    font = pygame.font.Font(None, 36)
    for i, option in enumerate(menu_options):
        text = font.render(option, True, (0, 0, 0) if i != selected_option else (255, 0, 0))
        text_rect = text.get_rect(center=(screen_size[0] // 2, screen_size[1] // 2 + i * 50))
        screen.blit(text, text_rect)

    pygame.display.flip()

pygame.quit()
